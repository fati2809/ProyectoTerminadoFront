import { Component } from '@angular/core';

@Component({
  selector: 'app-task-create',
  imports: [],
  templateUrl: './task-create.component.html',
  styleUrl: './task-create.component.css'
})
export class TaskCreateComponent {

}

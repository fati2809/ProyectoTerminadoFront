import { Component } from '@angular/core';

@Component({
  selector: 'app-recovery-password',
  imports: [],
  templateUrl: './recovery-password.component.html',
  styleUrl: './recovery-password.component.css'
})
export class RecoveryPasswordComponent {

}
